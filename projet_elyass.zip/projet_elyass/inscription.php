<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://fonts.googleapis.com/css2?family=Muli:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="page-connexion.css">
    <style>
        .srouce {
            text-align: center;
            color: #ffffff;
            padding: 10px;
        }
    </style>    
</head>
<body>

    <div class="main-container">
        <div class="form-container">

            <div class="srouce"><a title="hotel" href="./menu.html">luxury hotel</a></div>

            <div class="form-body">
                <h2 class="title">Sign up</h2>
                <div class="social-login">
                    <ul>
                        <li class="google"><a href="#">Google</a></li>
                        <li class="fb"><a href="#">Facebook</a></li>
                    </ul>
                </div><!-- SOCIAL LOGIN -->

                <div class="_or">or</div>

                <form action="" class="the-form" method="post">
                    <label for="firstname">First Name</label>
                    <input type="text" name="firstname" id="firstname" placeholder="Enter your first name">

                    <label for="lastname">Last Name</label>
                    <input type="text" name="lastname" id="lastname" placeholder="Enter your last name">

                    <label for="birthdate">Date of Birth</label>
                    <input type="date" name="birthdate" id="birthdate">

                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="Enter your email">

                    <label for="password">New Password</label>
                    <input type="password" name="password" id="password" placeholder="Enter your new password">

                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm your new password">

                    <input type="submit" value="Sign Up">
                </form>
            </div><!-- FORM BODY-->

            <div class="form-footer">
                <div>
                    <span>Already have an account?</span> <a href="connexion.php ?>">Log In</a>
                </div>
            </div><!-- FORM FOOTER -->

        </div><!-- FORM CONTAINER -->
    </div>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm_password"];

    if ($password === $confirmPassword) {
        $password = md5($password);

        $connect = mysqli_connect('localhost', 'root', '', 'sae_amar');
        if (!$connect) {
            die('Error: ' . mysqli_connect_error());
        }

        $firstname = $_POST["firstname"];
        $lastname = $_POST["lastname"];
        $email = $_POST["email"];

        // Vérifier si l'utilisateur existe déjà dans la base de données
        $existingUserQuery = mysqli_query($connect, "SELECT * FROM utilisateurs WHERE Email = '$email'");
        if (mysqli_num_rows($existingUserQuery) > 0) {
            // L'utilisateur existe déjà, afficher un message d'erreur ou rediriger vers une page d'inscription échouée
            die("L'utilisateur avec l'email '$email' existe déjà.");
        }

        // Insérer l'utilisateur dans la base de données
        $query = mysqli_query($connect, "INSERT INTO utilisateurs (Nom, Prenom, Email, Mot_de_passe) VALUES ('$lastname', '$firstname', '$email', '$password')");

        mysqli_close($connect);

        die("Inscription terminée. <a href='connexion.php'>Connectez-vous</a>.");

    } else {
        // Les mots de passe ne correspondent pas
        echo "<div style=\"text-align: center; border: 1px solid red; color:red; padding: 10px;\">Les mots de passe ne correspondent pas.</div>";
    }
}
?>
