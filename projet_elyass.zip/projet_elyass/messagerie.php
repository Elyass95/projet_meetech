<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Boîte de réception</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1 class="my-4">Boîte de réception</h1>
        <div class="row">
            <?php
            session_start();

            // Vérifiez si l'utilisateur est connecté
            if(isset($_SESSION['user'])) {
                // Récupérez le pseudo de l'utilisateur connecté depuis la session
                $destinataire = $_SESSION['user'];

                // Connexion à la base de données
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "projet";

                // Création de la connexion
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Vérifier la connexion
                if ($conn->connect_error) {
                    die("Connexion échouée: " . $conn->connect_error);
                }

                // Requête pour récupérer les messages reçus par l'utilisateur connecté
                $sql = "SELECT * FROM messages WHERE pseudo_destinataire = '$destinataire' ORDER BY date_envoi DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Afficher les messages reçus
                    while($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-6">';
                        echo '<div class="card mb-3">';
                        echo '<div class="card-body">';
                        echo '<h5 class="card-title">De: ' . $row["pseudo_emetteur"] . '</h5>';
                        echo '<p class="card-text">' . $row["contenu"] . '</p>';
                        echo '<p class="card-text"><small class="text-muted">Envoyé le: ' . $row["date_envoi"] . '</small></p>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="alert alert-warning" role="alert">';
                    echo "Boîte de réception vide";
                    echo '</div>';
                }

                // Fermer la connexion
                $conn->close();
            } else {
                // Rediriger l'utilisateur vers la page de connexion s'il n'est pas connecté
                header("Location: connexion.php");
                exit;
            }
            ?>
        </div>
    </div>
</body>

</html>
