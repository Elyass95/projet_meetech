

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>my presentation</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="stylev.css" type="text/css">
</head>
<body>
    <div class="hero">
        <video autoplay loop muted class="back-video">
            <source src="./video_menu.mp4" type="video/mp4">
        </video>
        <nav>
            <ul>
                <li><a href="menu.html">HOME</a></li>
                <li><a href="mailto:amirrr957@gmail.com">CONTACT ME</a></li>
                <li><a href="connexion.php">CONNEXION</a></li>
                
            </ul>
        </nav>
        <img src="./uvsq_hotel_1.jpg" style="width: 180px; height: auto; position: absolute; top: 10px; left: 10px; z-index: 1;">
        <div class="content">
            <h1>LUXURY HOTEL</h1>
            <a href="reservation.html">Réserver maintenant</a>
        </div>
    </div>
</body>
</html>
