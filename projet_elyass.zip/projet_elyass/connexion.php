<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $connect = mysqli_connect('localhost', 'root', '', 'sae_amar');
    if (!$connect) {
        die('Error: ' . mysqli_connect_error());
    }

    $query = mysqli_query($connect, "SELECT * FROM utilisateurs WHERE Email = '$email'");
    if (mysqli_num_rows($query) > 0) {
        $user = mysqli_fetch_assoc($query);
        $storedPassword = $user['Mot_de_passe'];

        if (md5($password) === $storedPassword) {
            $_SESSION['user'] = $email; // Utilisation de l'email comme nom d'utilisateur
            $_SESSION['prenom'] = $user['Prenom']; // Stockage du prénom de l'utilisateur

            mysqli_close($connect);
            header("Location: ./hotel/index2.php");
            exit();
        } else {
            echo "<div style=\"text-align: center; border: 1px solid red; color:red; padding: 10px;\">Mot de passe incorrect.</div>";
        }
    } else {
        echo "<div style=\"text-align: center; border: 1px solid red; color:red; padding: 10px;\">Utilisateur non trouvé.</div>";
    }

    mysqli_close($connect);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page </title>
    <link href="https://fonts.googleapis.com/css2?family=Muli:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="page-connexion.css">
    <style>
        .srouce{
            text-align: center;
            color: #ffffff;
            padding: 10px;
        }
    </style>
</head>
<body>

    <div class="main-container">
        <div class="form-container">

            <div class="srouce"><a title="hotel" href="./menu.html">luxury hotel</a></div>

            <div class="form-body">
                <h2 class="title">Log in with</h2>
                <div class="social-login">
                    <ul>
                        <li class="google"><a href="#">Google</a></li>
                        <li class="fb"><a href="#">Facebook</a></li>
                    </ul>
                </div><!-- SOCIAL LOGIN -->

                <div class="_or">or</div>

                <form action="" class="the-form" method="post">

                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="Enter your email">

                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" placeholder="Enter your password">

                    <input type="submit" value="Log In">

                </form>

            </div><!-- FORM BODY-->

            <div class="form-footer">
                <div>
                    <span>Don't have an account?</span> <a href="./inscription.php">Sign Up</a>
                </div>
            </div><!-- FORM FOOTER -->

        </div><!-- FORM CONTAINER -->
    </div>

</body>
</html>
