


<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: connexion.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>UVSQ Hotel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="">
    <meta name="description" content="">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <style>
        /* CSS code here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background-color: #333;
            padding: 20px;
            color: #fff;
            display: flex;
            justify-content: space-between;
        }

        .header h1 {
            margin: 0;
        }

        .header .contact-info {
            display: flex;
            align-items: center;
        }

        .header .contact-info i {
            margin-right: 5px;
        }

        .nav {
            background-color: #333;
            padding: 20px;
        }

        .nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
            display: flex;
            justify-content: space-between;
        }

        .nav ul li {
            margin-right: 10px;
        }

        .nav ul li a {
            text-decoration: none;
            color: #fff;
            padding: 5px 10px;
            border-radius: 3px;
        }

        .nav ul li a:hover {
            background-color: #fff;
            color: #333;
        }

        .section {
            padding: 20px;
            text-align: center;
        }

        .section h2 {
            margin-bottom: 20px;
        }

        .room-card {
            margin: 0 auto 20px;
            max-width: 300px;
        }

        .room-card img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }

        .room-card .card-body {
            padding: 10px;
        }

        .room-card h5 {
            margin: 0;
        }

        .room-card p {
            margin: 10px 0;
        }

        .room-card .btn-primary {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            text-decoration: none;
        }

        .room-card .btn-primary:hover {
            background-color: #fff;
            color: #333;
        }

        .footer {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Start -->
        <div class="header">
            <h1>UVSQ Hotel</h1>
            <div class="contact-info">
                <i class="fa fa-envelope"></i>
                <p>SAE@example.com</p>
                <i class="fa fa-phone-alt"></i>
                <p>+123 456 7890</p>
            </div>
        </div>
        <!-- Header End -->

        <!-- Navigation Start -->
        <div class="nav">
            <ul>
                <li><a href="index2.php">Home</a></li>
                <li><a href="room.php">Rooms</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="logout.php"><?php echo $_SESSION['user']; ?></li>
            </ul>
        </div>
        <!-- Navigation End -->

        <!-- Section Start -->
        <div class="section">
            <h2>Welcome to UVSQ Hotel</h2>
            <p>Welcome to our room booking website! Reserve your stay now to enjoy a memorable experience. Happy browsing!</p>

            <div class="room-card">
                <img src="./img/uvsq.jpg" alt="Room Image">
                <div class="card-body">
                    
                    
                </div>
            </div>
        </div>
        <!-- Section End -->

        <!-- Footer Start -->
        <div class="footer">
            <p>&copy; 2023 UVSQ Hotel. All rights reserved. Design by <a href="https://www.example.com/">Example</a>.
            </p>
        </div>
        <!-- Footer End -->
    </div>
</body>
</html>
